#!/bin/bash

program_name="x-night223"
SUFFIX="ngt223"
this_dir=""
log_file=""

# the directory where this script file is.
function enter_cur_dir(){
     this_dir=`pwd`
     dirname $0|grep "^/" >/dev/null
     if [ $? -eq 0 ];then
             this_dir=`dirname $0`
     else
             dirname $0|grep "^\." >/dev/null
             retval=$?
             if [ $retval -eq 0 ];then
                     this_dir=`dirname $0|sed "s#^.#$this_dir#"    `
             else
                     this_dir=`dirname $0|sed "s#^#$this_dir/#"    `
             fi
     fi

    cd $this_dir
}


# backup log
function backup(){
# process strategies' log files
        STRA_LOG="../backup/czce_stra_${SUFFIX}_`date +%y%m%d`.tar.gz"
        STRA_LOG_DIR="../backup/czce_stra_${SUFFIX}_`date +%y%m%d`"
        if [ -a $STRA_LOG ]
        then
            exit 1
        fi

        mkdir -p  $STRA_LOG_DIR
	cd log
	    rename .txt _910223.txt *.txt

	cd ..
	cp -v  ./*.pos ./*.log ./log/*.txt $STRA_LOG_DIR
        rm -v  ./log/*.txt ./*.pos ./*.log

        tar -cvzf $STRA_LOG $STRA_LOG_DIR
        if [ $? -eq 0 ]
        then
                rm -fr $STRA_LOG_DIR
        fi

}

#kill process and exit
pkill --signal SIGUSR1 $program_name 

echo "after kill"
 pid=$(ps -e  |grep $program_name | awk '{print $1}')
 len=${#pid}
 echo "len:${len}"
 while [ $len -gt 0  ]
 do
     pid=$(ps -e  |grep $program_name | awk '{print $1}')
     len=${#pid}
     echo "len:${len}"
     echo "pid:${pid}"
     sleep 1
 done

echo "wake up"


enter_cur_dir
backup

