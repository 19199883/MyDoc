#!/usr/bin/bash

python ./pos_sum.py
