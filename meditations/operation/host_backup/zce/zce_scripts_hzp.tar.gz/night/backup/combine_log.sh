#!/bin/bash

this_dir=""

# get the directory where this script file itself locates.
 this_dir=`pwd`
 dirname $0|grep "^/" >/dev/null
 if [ $? -eq 0 ];then
         this_dir=`dirname $0`
 else
         dirname $0|grep "^\." >/dev/null
         retval=$?
         if [ $retval -eq 0 ];then
                 this_dir=`dirname $0|sed "s#^.#$this_dir#"`
         else
                 this_dir=`dirname $0|sed "s#^#$this_dir/#"`
         fi
 fi

cd $this_dir

# combine strategy logs 
STRA_LOG_223_SRC="../../night223/backup/czce_stra_ngt223_`date +%y%m%d`.tar.gz"
tar -xvzf $STRA_LOG_223_SRC 

STRA_LOG_DEST="czce_stra_ngt_`date +%y%m%d`.tar.gz"
tar -cvzf $STRA_LOG_DEST ./backup
rm -r ./backup
