#!/bin/bash
usage_size=0
# 10G
threshold=30

for usage_str in `du -sh -B G ~`
do
	len=${#usage_str}
	usage_size=${usage_str:0:$len-1}
	break
done

if [ $usage_size -gt $threshold ]
then	
	echo -e "\e[41;37m WARING: CLEAR RUBBISH,PLEASE!!! USAGE:${usage_size}G \033[0m"
fi
