tar -czf dce_scripts.tar.gz `find . -name "*.sh" -o -name "*.config" -o -name "*.xml"`
