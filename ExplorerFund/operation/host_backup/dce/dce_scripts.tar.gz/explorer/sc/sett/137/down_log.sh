#!/bin/bash
SUFFIX="day"
program_name="dce_trad_${SUFFIX}"

STRATEGY_DIR="./stra_log"

# obtain the directory where this script file locates.
 this_dir=`pwd`
 dirname $0|grep "^/" >/dev/null
 if [ $? -eq 0 ];then
         this_dir=`dirname $0`
 else
         dirname $0|grep "^\." >/dev/null
         retval=$?
         if [ $retval -eq 0 ];then
                 this_dir=`dirname $0|sed "s#^.#$this_dir#"`
         else
                 this_dir=`dirname $0|sed "s#^#$this_dir/#"`
         fi
 fi

cd $this_dir


STRA_LOG="/home/u910019/explorer/day137/backup/dce_trad_${SUFFIX}_`date +%y%m%d`.tar.gz"
scp -P 22  "u910019@172.18.80.5:${STRA_LOG}" ${STRATEGY_DIR}

