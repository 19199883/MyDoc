#!/bin/bash
SUFFIX="day"
CONTRACTS=""

program_name="dce_mkt_day112"
this_dir=""

# the directory where this script file is
function enter_cur_dir(){
	 this_dir=`pwd`
	 dirname $0|grep "^/" >/dev/null
	 if [ $? -eq 0 ];then
			 this_dir=`dirname $0`
	 else
			 dirname $0|grep "^\." >/dev/null
			 retval=$?
			 if [ $retval -eq 0 ];then
					 this_dir=`dirname $0|sed "s#^.#$this_dir#"`
			 else
					 this_dir=`dirname $0|sed "s#^#$this_dir/#"`
			 fi
	 fi

	cd $this_dir
}

# backup log and Data
function backup(){
	IN_FILE_BEST_AND_DEEP="bestanddeepquote_`date +%Y%m%d`.dat"
	IN_FILE_ORDERSTATISTIC="orderstatistic_`date +%Y%m%d`.dat"
	OUT_DIR="../backup/dce_md_${SUFFIX}_`date +%y%m%d`/"
	OUT_FILE="../backup/dce_md_${SUFFIX}_`date +%y%m%d`.tar.gz"
	OUT_TOP="../backup/"

	if [ -a $OUT_FILE ]
	then
		exit 1
	fi 

	mkdir -p $OUT_TOP
	if [ $? -ne 0 ]
	then
		exit 1
	fi 

	mkdir -p $OUT_DIR
	if [ $? -ne 0 ]
	then
		exit 1
	fi 

	cp "./Data/${IN_FILE_BEST_AND_DEEP}" $OUT_DIR
	./md_split "${OUT_DIR}${IN_FILE_BEST_AND_DEEP}" $CONTRACTS
	if [ $? -eq 0 ]
	then
		rm ${OUT_DIR}${IN_FILE_BEST_AND_DEEP}
	fi

	cp "./Data/${IN_FILE_ORDERSTATISTIC}" $OUT_DIR
	./md_split "${OUT_DIR}${IN_FILE_ORDERSTATISTIC}" $CONTRACTS
	if [ $? -eq 0 ]
	then
		rm ${OUT_DIR}${IN_FILE_ORDERSTATISTIC}
	fi

	tar -czf $OUT_FILE $OUT_DIR
	if [ $? -eq 0 ]
	then
		rm -rf $OUT_DIR
	fi

	mkdir -p  ../backup/
	log_file="../backup/${program_name}_`date +%y%m%d`.tar.gz"
	if [ -a $log_file ]
	then
		exit 1
	fi

	tar -czf $log_file   ./Data *.log
	if [ $? -eq 0 ]
	then
		rm *.log
		rm core.*
		rm Data/*
	fi
}

enter_cur_dir
backup
