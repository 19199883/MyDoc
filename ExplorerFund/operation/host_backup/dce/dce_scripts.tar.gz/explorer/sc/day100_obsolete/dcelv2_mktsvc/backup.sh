program_name="dce_mkt_day100"
this_dir=""
log_file=""

# the directory where this script file is.
function enter_cur_dir(){
	 this_dir=`pwd`
	 dirname $0|grep "^/" >/dev/null
	 if [ $? -eq 0 ];then
			 this_dir=`dirname $0`
	 else
			 dirname $0|grep "^\." >/dev/null
			 retval=$?
			 if [ $retval -eq 0 ];then
					 this_dir=`dirname $0|sed "s#^.#$this_dir#"`
			 else
					 this_dir=`dirname $0|sed "s#^#$this_dir/#"`
			 fi
	 fi

	cd $this_dir
}

# backup log and Data
function backup(){
	mkdir -p  ../backup/

	log_file="../backup/${program_name}_`date +%y%m%d`.tar.gz"
	if [ -a $log_file ];then
		exit 1
	fi

	tar -czf $log_file   ./Data *.log
	if [ $? -eq 0 ]
	then
		rm *.log core.*  Data/*
	fi
}

enter_cur_dir
backup
