#!/bin/bash
pkill -9  dce_mkt_day28


