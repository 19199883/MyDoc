#!/bin/bash
PROGRAM=czce_mkt_day101

pkill -9  $PROGRAM
