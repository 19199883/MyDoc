#!/bin/bash
SUFFIX="ngt101"
CONTRACTS=""
EXCHANGE=czce
program_name="czce_mkt"
DATA_FILE_PREFIX="czce_level2"
this_dir=""

# the directory where this script file is
function enter_cur_dir(){
     this_dir=`pwd`
     dirname $0|grep "^/" >/dev/null
     if [ $? -eq 0 ];then
             this_dir=`dirname $0`
     else
             dirname $0|grep "^\." >/dev/null
             retval=$?
             if [ $retval -eq 0 ];then
                     this_dir=`dirname $0|sed "s#^.#$this_dir#"    `
             else
                     this_dir=`dirname $0|sed "s#^#$this_dir/#"    `
             fi
     fi

    cd $this_dir
}

# backup log and Data
function backup(){
        LAST_DAY=`date -d "-1 days" +"%Y%m%d"`
        IN_FILE="${DATA_FILE_PREFIX}_${LAST_DAY}.dat"
        OUT_DIR="../backup/${EXCHANGE}_md_${SUFFIX}_`date +%y%m%d`/"
        OUT_FILE="../backup/${EXCHANGE}_md_${SUFFIX}_`date +%y%m%d`.tar.gz"
        OUT_TOP="../backup/"

        if [ -a $OUT_FILE ]
        then
            exit 1
        fi

        mkdir -p $OUT_TOP
        if [ $? -ne 0 ]
        then
            exit 1
        fi

        mkdir -p $OUT_DIR
        if [ $? -ne 0 ]
        then
            exit 1
        fi

        cp "./Data/${IN_FILE}" $OUT_DIR
        ./md_split "${OUT_DIR}${IN_FILE}" $CONTRACTS
        if [ $? -eq 0 ]
        then
                rm ${OUT_DIR}${IN_FILE}
        fi

        tar -cvzf $OUT_FILE $OUT_DIR
        if [ $? -eq 0 ]
        then
                rm -rf $OUT_DIR
        fi

        mkdir -p  ../backup/
        log_file="../backup/${program_name}_`date +%y%m%d`.tar.gz"
        if [ -a $log_file ]
        then
            exit 1
        fi

        tar -cvzf $log_file   ./Data *.log
        if [ $? -eq 0 ]
        then
                rm *.log-*
                rm *.log
                rm core.*
                rm Data/*
        fi
}

enter_cur_dir
backup

