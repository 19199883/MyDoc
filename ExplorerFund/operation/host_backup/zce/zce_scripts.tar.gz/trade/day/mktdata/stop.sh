#!/bin/bash
PROGRAM=czce_mkt_day

pkill -9  $PROGRAM
