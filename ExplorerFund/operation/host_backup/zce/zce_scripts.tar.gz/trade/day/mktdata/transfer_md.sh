#!/bin/bash
SUFFIX="day"
CONTRACTS=""
EXCHANGE=czce
program_name="czce_mkt"
DATA_FILE_PREFIX="czce_level2"
this_dir=""

# get the directory where this script file locates.
 this_dir=`pwd`
 dirname $0|grep "^/" >/dev/null
 if [ $? -eq 0 ];then
         this_dir=`dirname $0`
 else
         dirname $0|grep "^\." >/dev/null
         retval=$?
         if [ $retval -eq 0 ];then
                 this_dir=`dirname $0|sed "s#^.#$this_dir#"`
         else
                 this_dir=`dirname $0|sed "s#^#$this_dir/#"`
         fi
 fi

cd $this_dir

# backup log and Data
IN_FILE="${DATA_FILE_PREFIX}_`date +%Y%m%d`.dat"
OUT_DIR="../backup/${EXCHANGE}_md_${SUFFIX}_`date +%y%m%d`/"
OUT_FILE="../backup/${EXCHANGE}_md_${SUFFIX}_`date +%y%m%d`.tar.gz"
OUT_TOP="../backup/"

mkdir -p $OUT_TOP
mkdir -p $OUT_DIR

cp "./Data/${IN_FILE}" $OUT_DIR
./md_split "${OUT_DIR}${IN_FILE}" $CONTRACTS

#copy all *.dat files to the directory ~/domi_contr_check/ where a utility check if dominant contracts change.
cp ${OUT_DIR}* ~/domi_contr_check/

if [ $? -eq 0 ]
then
	rm ${OUT_DIR}${IN_FILE}
fi

tar -cvzf $OUT_FILE $OUT_DIR
if [ $? -eq 0 ]
then
	rm -rf $OUT_DIR
fi


rm Data/*

log_file=$program_name"_"`date +%y%m%d`.tar.gz
tar -cvzf $log_file   ./Data *.log
if [ $? -eq 0 ]
then
	rm *.log-*
	rm core.*
	rm Data/*
fi
mkdir -p  ../backup/
mv -f $log_file ../backup/

