#!/bin/bash
PROGRAM=czce_mkt_day17

pkill -9  $PROGRAM
