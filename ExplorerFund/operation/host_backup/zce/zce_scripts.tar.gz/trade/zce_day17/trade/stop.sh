#!/bin/bash

program_name="czce_tra_day17"
pkg_name="czce_tra_day"
this_dir=""
log_file=""

# the directory where this script file is.
function enter_cur_dir(){
     this_dir=`pwd`
     dirname $0|grep "^/" >/dev/null
     if [ $? -eq 0 ];then
             this_dir=`dirname $0`
     else
             dirname $0|grep "^\." >/dev/null
             retval=$?
             if [ $retval -eq 0 ];then
                     this_dir=`dirname $0|sed "s#^.#$this_dir#"    `
             else
                     this_dir=`dirname $0|sed "s#^#$this_dir/#"    `
             fi
     fi

    cd $this_dir
}


# backup log
function backup(){
	mkdir -p  ../backup/
        if [ $? -ne 0 ]
        then
            exit 1
        fi

	log_file="../backup/${pkg_name}_`date +%y%m%d`.tar.gz"
        if [ -a $log_file ]
        then
            echo "error:${log_file} already exits!"
            exit 1
        fi

	tar -cvzf $log_file   ./log *.log
        if [ $? -eq 0 ]
        then
            rm -f *.log ./log/*
        fi

}

#kill process and exit
pkill -9  $program_name 

enter_cur_dir
backup

