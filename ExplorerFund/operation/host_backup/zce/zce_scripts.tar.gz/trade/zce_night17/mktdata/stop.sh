#!/bin/bash
PROGRAM=czce_mkt_ngt17

pkill -9  $PROGRAM
