#!/bin/bash
PROGRAM=czce_mkt_night

pkill -9  $PROGRAM
