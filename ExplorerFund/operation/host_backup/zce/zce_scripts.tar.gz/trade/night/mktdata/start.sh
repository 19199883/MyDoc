#!/bin/bash
PROGRAM=czce_mkt_night
echo $PROGRAM
# the following codes obtain the directory where this script file locates.
 this_dir=`pwd`
 dirname $0|grep "^/" >/dev/null
 if [ $? -eq 0 ];then
         this_dir=`dirname $0`
 else
         dirname $0|grep "^\." >/dev/null
         retval=$?
         if [ $retval -eq 0 ];then
                 this_dir=`dirname $0|sed "s#^.#$this_dir#"`
         else
                 this_dir=`dirname $0|sed "s#^#$this_dir/#"`
         fi
 fi

cd $this_dir

ulimit -c unlimited
export LD_LIBRARY_PATH=./:$LD_LIBRARY_PATH
nohup ./$PROGRAM &
